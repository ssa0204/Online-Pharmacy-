# Project-Group-1
CSCE 5430 Project
This is a Web Based Online Pharmacy Store that is being developed in PHP, Bootstarp and CSS.
Details of how to view any updated changes will be posted in this file.
The details of the project folder Structure are as follows:
1. All the stylesheets will be saved within the CSS folder.
2. The .PHP files will be saved in the parent folder(Project-Group-1)
3. Separate folders called Images is created to save all the images being used in the website.
4. Separate folder called Documents has been created where we will find all the documentation(Deliverables) necessary.
5. There is also a script folder to save the .js files.


*************************** Date: 10/21/2019 11:50 p.m ***************************************
To be able to install and run the web page, Be sure to have a working version of the Xampp control panel. 
Save the folder SeEngg to the following path: c:/xampp/htdocs
Then open xampp and start apache service and mysql service
Next open browser and type the following url
localhost:port_number/SwEngg/loginnew.php
This should take you to the home page

**************************** REFERENCES for Code till 10/21/2019  *******************************
https://themeforest.net/category/site-templates/admin-templates?term=ecommerce%20html
https://p.w3layouts.com/demos/june-2016/01-06-2016/big_store/web/login.html

